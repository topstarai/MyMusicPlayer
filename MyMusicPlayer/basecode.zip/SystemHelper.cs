﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MyMusicPlayer
{
    class SystemHelper
    {
        public static Bitmap CloneCoveredBackground(Bitmap bitmap,int x, int y, int width, int height)
        {
            //绘制矩形，定义起始位置和宽高
            Rectangle r = new Rectangle(x, y, width, height);
            //按矩形尺寸和起始位置截取bm的一部分
            return bitmap.Clone(r, bitmap.PixelFormat);
        }

        public static void SetListViewBackground(ListView listView,Bitmap bitmap)
        {
            var bm = CloneCoveredBackground(bitmap,listView.Location.X, listView.Location.Y, listView.Width, listView.Height);
            //把截取到的图片设置为lv背景，达到与主窗体背景完美契合的效果
            listView.BeginUpdate();
            listView.BackgroundImage = (Image)bm;
            listView.EndUpdate();
        }
    }
}
